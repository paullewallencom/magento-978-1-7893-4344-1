# Magento 2 Quick Start Guide

## Chapter 3: Understanding Web API

The minimal web API example module written for Chapter 3.