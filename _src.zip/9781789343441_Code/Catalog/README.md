# Magento 2 Quick Start Guide

The sample module, demonstrating customizations of catalog behaviour.

Implements:
- Size Guide
- Same Day Delivery (Shows "You have 6h 24min 34sec to catch our same day delivery offer.")