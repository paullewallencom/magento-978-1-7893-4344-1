var config = {
    map: {
        '*': {
            cutoffAt: 'Magelicious_Catalog/js/cutoff'
        }
    }
};