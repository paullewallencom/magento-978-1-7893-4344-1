<?php

namespace Magelicious\Core\Cron;

class TheJob
{
    public function execute()
    {
        // ...
    }
}