# Magento 2 Quick Start Guide

## Chapter 4: Building and Distributing Extensions

The sample module for chapter 4.