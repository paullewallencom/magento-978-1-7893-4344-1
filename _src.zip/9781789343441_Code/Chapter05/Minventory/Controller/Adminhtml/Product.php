<?php

namespace Magelicious\Minventory\Controller\Adminhtml;

abstract class Product extends \Magento\Backend\App\Action
{
    const ADMIN_RESOURCE = 'Magelicious_Minventory::minventory';
}
