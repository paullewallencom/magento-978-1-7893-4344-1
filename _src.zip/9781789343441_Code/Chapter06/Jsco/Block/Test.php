<?php

namespace Magelicious\Jsco\Block;

class Test extends \Magento\Framework\View\Element\Template
{

}
