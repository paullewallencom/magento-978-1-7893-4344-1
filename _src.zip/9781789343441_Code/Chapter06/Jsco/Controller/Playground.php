<?php

namespace Magelicious\Jsco\Controller;

abstract class Playground extends \Magento\Framework\App\Action\Action
{

}
