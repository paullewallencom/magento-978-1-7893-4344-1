# Magento 2 Quick Start Guide

The sample module, demonstrating storefront JavaScript components.