var config = {
    map: {
        '*': {
            welcome: 'Magelicious_Jsco/js/welcome',
            popularProducts: 'Magelicious_Jsco/js/new-popular-products'
        }
    },
    config: {
        mixins: {
            'mage/redirect-url': {
                'Magelicious_Jsco/js/redirect-url-mixin': true
            }
        }
    }
};