var config = {
    map: {
        '*': {
            contactPreferences: 'Magelicious_ContactPreferences/js/view/contact-preferences'
        }
    }
};