<?php

namespace Magelicious\OrderNotes\Controller;

abstract class Index extends \Magento\Framework\App\Action\Action
{

}
