# Magento 2 Quick Start Guide

The sample module, demonstrating checkout modifications.